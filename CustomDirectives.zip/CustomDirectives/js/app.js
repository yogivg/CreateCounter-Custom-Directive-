var app = angular.module("myApp", ['ui.router']);
 
  app.directive("counterWidget",function(){
      return{
          restrict: 'E',
          scope: {
              startnumber: '='
          },
          link: function(scope,elem,attr){
            scope.f = attr.startnumber;
            scope.increament = function(){
                scope.f++;
            }
            scope.decreament = function(){
                scope.f--;
            }
            scope.reset = function(){
                scope.f = 0;
            }
        },
          templateUrl: 'counter.html'
      }
  });